#!/usr/bin/env bash
# Install, test and remove Zyvor Retail on one Linux or macOS machine (docker or podman).
#
#   deploy/install/install.sh up --demo     try it: fictional catalogue, generated admin password
#   deploy/install/install.sh test          checks that what is running answers correctly
#   deploy/install/install.sh engine        checks (and offers to install) the container engine
#   deploy/install/install.sh status | logs | down | uninstall
#
# Options:  --host NAME     address the browser uses (default 127.0.0.1)
#           --port N        HTTP port (default 8080)
#           --version V     image tag (default from VERSION or 0.25.0)
#           --registry R    image registry/namespace (default ghcr.io/zyvorai)
#           --yes           answer yes to "install podman for you?"
#           --no-open       do not open the browser when it is ready
#           --dir D         where settings and passwords live (default ~/.zyvor-retail)
#           --project NAME  container project name (default zyvor-retail)
# Fictional data only: not a certified tax or accounting system.
set -euo pipefail

SRC="$(cd "$(dirname "$0")/../.." && pwd)"
CMD="${1:-help}"; [ "$#" -gt 0 ] && shift
DIR="${RETAIL_INSTALL_DIR:-$HOME/.zyvor-retail}"; PROJECT="zyvor-retail"
HOST=""; PORT=""; DEMO=""; VERSION=""; REGISTRY=""; NO_OPEN=""; ASSUME_YES=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --demo) DEMO=1 ;; --no-open) NO_OPEN=1 ;; --yes) ASSUME_YES=1 ;;
    --version) VERSION="${2:?--version needs a value}"; shift ;;
    --registry) REGISTRY="${2:?--registry needs a value}"; shift ;;
    --host) HOST="${2:?--host needs a value}"; shift ;;
    --port) PORT="${2:?--port needs a value}"; shift ;;
    --dir) DIR="${2:?--dir needs a value}"; shift ;;
    --project) PROJECT="${2:?--project needs a value}"; shift ;;
    -*) echo "unknown option: $1" >&2; exit 2 ;;
    *) echo "unexpected argument: $1" >&2; exit 2 ;;
  esac; shift
done
ENVF="$DIR/env"
say() { printf '%s\n' "$*"; }
die() { printf 'error: %s\n' "$*" >&2; exit 1; }
rand() { openssl rand -hex 12; }
saved() { [ -f "$ENVF" ] && sed -n "s/^$1=//p" "$ENVF" | head -1 || true; }

confirm() {
  [ -n "$ASSUME_YES" ] && [ -z "${STRICT:-}" ] && return 0
  (: < /dev/tty) 2>/dev/null || return 1
  printf '%s [Y/n] ' "$1" > /dev/tty
  local a; read -r a < /dev/tty || return 1
  case "$a" in ''|y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

install_engine() {
  local what="$1"
  local pkgs="podman podman-compose"; [ "$what" = "podman-compose" ] && pkgs="podman-compose"
  case "$(uname -s)" in
    Darwin)
      if ! command -v brew >/dev/null 2>&1; then
        STRICT=1 confirm "Zyvor Retail needs a container engine. First install Homebrew (from brew.sh; it asks for your Mac password)?" || return 1
        say "Installing Homebrew (a few minutes)..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || { say "The Homebrew installer did not finish."; return 1; }
        eval "$(/opt/homebrew/bin/brew shellenv 2>/dev/null || /usr/local/bin/brew shellenv 2>/dev/null)"
        command -v brew >/dev/null 2>&1 || return 1
      fi
      confirm "Zyvor Retail needs a container engine. Install $what now with Homebrew?" || return 1
      say "Installing $pkgs with Homebrew (a minute or two)..."
      brew install $pkgs >/dev/null 2>&1 || { say "brew install $pkgs failed; run it yourself to see why."; return 1; } ;;
    Linux)
      local sudo=""
      if [ "$(id -u)" -ne 0 ]; then command -v sudo >/dev/null 2>&1 || return 1; sudo=sudo; fi
      local cmd
      if command -v apt-get >/dev/null 2>&1; then cmd="$sudo apt-get update -qq && $sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y -qq $pkgs"
      elif command -v dnf >/dev/null 2>&1; then cmd="$sudo dnf install -y -q $pkgs"
      else return 1; fi
      confirm "Zyvor Retail needs a container engine. Install $what now${sudo:+ (uses sudo, which may ask for your password)}?" || return 1
      say "Installing $pkgs (a minute or two)..."
      sh -c "$cmd" >/dev/null 2>&1 || { say "Installing $pkgs failed; run '${cmd}' yourself to see why."; return 1; } ;;
    *) return 1 ;;
  esac
}

start_docker_desktop() {
  [ "$(uname -s)" = Darwin ] && [ -d /Applications/Docker.app ] || return 1
  say "Opening Docker Desktop and waiting for it to be ready (up to 3 minutes)..."
  open -a Docker >/dev/null 2>&1 || return 1
  local n=90; while [ "$n" -gt 0 ]; do docker info >/dev/null 2>&1 && return 0; sleep 2; n=$((n - 1)); done
  return 1
}

engine_help() {
  say "Zyvor Retail needs a container engine, and none is ready on this computer."
  case "$(uname -s)" in
    Darwin)
      say "  1. Install Docker Desktop: https://www.docker.com/products/docker-desktop/   (or: brew install podman podman-compose)"
      say "  2. Open Docker Desktop once and wait until it says it is running."
      say "  3. Run the same command again." ;;
    *)
      say "  Install Docker (https://docs.docker.com/engine/install/) or podman:"
      say "    Debian/Ubuntu:  sudo apt install podman podman-compose      Fedora:  sudo dnf install podman podman-compose"
      say "  Then run the same command again." ;;
  esac
  exit 1
}

ensure_podman_machine() {
  [ "$(uname -s)" = Darwin ] || return 0
  podman info >/dev/null 2>&1 && return 0
  if [ -z "$(podman machine list --format '{{.Name}}' 2>/dev/null)" ]; then
    say "Creating podman's small Linux VM (one time, a few minutes)..."
    podman machine init >/dev/null 2>&1 || die "could not create the podman VM; try: podman machine init"
  fi
  say "Starting podman's Linux VM..."
  podman machine start >/dev/null 2>&1 || true
  podman info >/dev/null 2>&1 || die "podman's VM did not start; try: podman machine start"
}

pick_engine() {
  if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1 && docker info >/dev/null 2>&1; then ENGINE=docker; COMPOSE=(docker compose); return 0; fi
  if command -v podman >/dev/null 2>&1; then
    if command -v podman-compose >/dev/null 2>&1; then ENGINE=podman; COMPOSE=(podman-compose); ensure_podman_machine; return 0; fi
    if podman compose version >/dev/null 2>&1; then ENGINE=podman; COMPOSE=(podman compose); ensure_podman_machine; return 0; fi
    if install_engine podman-compose && command -v podman-compose >/dev/null 2>&1; then ENGINE=podman; COMPOSE=(podman-compose); ensure_podman_machine; return 0; fi
    say "podman is installed but podman-compose is not."
    case "$(uname -s)" in Darwin) say "  Run: brew install podman-compose, then run the same command again." ;; *) say "  Install podman-compose, then run the same command again." ;; esac
    exit 1
  fi
  if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    if start_docker_desktop; then ENGINE=docker; COMPOSE=(docker compose); return 0; fi
    say "Docker is installed but not running. Open Docker Desktop, wait until it is ready, then run the same command again."
    exit 1
  fi
  if install_engine "podman and podman-compose" && command -v podman >/dev/null 2>&1; then pick_engine; return 0; fi
  engine_help
}

open_url() {
  [ -n "$NO_OPEN" ] && return 0
  [ -n "${WSL_DISTRO_NAME:-}" ] && return 0
  case "$(uname -s)" in Darwin) open "$1" ;; *) command -v xdg-open >/dev/null 2>&1 && xdg-open "$1" ;; esac >/dev/null 2>&1 || true
}

compose() {
  (cd "$SRC/deploy/install" && "${COMPOSE[@]}" -p "$PROJECT" --env-file "$ENVF" -f compose.yaml "$@")
}

wait_for() {
  local what="$1" n="$2"; shift 2
  while [ "$n" -gt 0 ]; do "$@" >/dev/null 2>&1 && return 0; sleep 2; n=$((n - 2)); done
  die "timed out waiting for $what (see: $0 logs)"
}

write_env() {
  [ -f "$ENVF" ] && return 0
  [ -n "$HOST" ] || HOST=127.0.0.1
  PORT="${PORT:-8080}"
  local tag reg email pass
  tag="${VERSION:-$(cat "$SRC/VERSION" 2>/dev/null || echo 0.25.0)}"
  reg="${REGISTRY:-ghcr.io/zyvorai}"
  # Public trial image lives on the site package (anonymous pull); private repo image is optional.
  img_name="${RETAIL_IMAGE_NAME:-zyvor-retail-site}"
  email="${RETAIL_ADMIN_EMAIL:-owner@zyvor.local}"
  pass="$(rand)$(rand)"
  mkdir -p "$DIR"; umask 077
  {
    echo "RETAIL_ADMIN_EMAIL=$email"
    echo "RETAIL_ADMIN_PASSWORD=$pass"
    echo "RETAIL_PUBLIC_ORIGIN=http://$HOST:$PORT"
    echo "RETAIL_SECURE_COOKIE=0"
    echo "RETAIL_HTTP_BIND=127.0.0.1"
    echo "RETAIL_HTTP_PORT=$PORT"
    echo "RETAIL_IMAGE=$reg/$img_name:$tag"
    echo "RETAIL_IMAGE_TAG=$tag"
    echo "RETAIL_IMAGE_REGISTRY=$reg"
    echo "RETAIL_INSTALL_DIR=$DIR"
    [ -n "$DEMO" ] && echo "RETAIL_DEMO=1"
  } > "$ENVF"
  chmod 600 "$ENVF"
}

do_up() {
  command -v openssl >/dev/null 2>&1 || die "openssl is required"
  command -v curl >/dev/null 2>&1 || die "curl is required"
  [ -n "$DEMO" ] || DEMO=1
  pick_engine
  write_env
  local url img; url="$(saved RETAIL_PUBLIC_ORIGIN)"; img="$(saved RETAIL_IMAGE)"
  say "Zyvor Retail with $ENGINE, project $PROJECT, settings in $DIR"
  say "pulling $img"
  compose pull >/dev/null 2>&1 || "$ENGINE" pull "$img" >/dev/null 2>&1 || die "could not pull $img — is the package public on GHCR?"
  compose up -d >/dev/null
  wait_for "the app ($url)" 120 curl -fsS "$url/readyz"
  printf '#!/bin/sh\nexec "%s" "$@" --dir "%s" --project "%s"\n' "$SRC/deploy/install/install.sh" "$DIR" "$PROJECT" > "$DIR/zyvor-retail"
  chmod 755 "$DIR/zyvor-retail"
  local short="${DIR/#$HOME/\~}/zyvor-retail"
  say ""
  say "Zyvor Retail is running:  $url"
  say "Sign in with:"
  say "  email:     $(saved RETAIL_ADMIN_EMAIL)"
  say "  password:  $(saved RETAIL_ADMIN_PASSWORD)"
  say "(also saved in $ENVF — keep that file private)"
  say ""
  say "Next:    $short test"
  say "Remove:  $short uninstall"
  open_url "$url"
}

do_test() {
  command -v curl >/dev/null 2>&1 || die "curl is required"
  [ -f "$ENVF" ] || die "nothing installed here ($ENVF missing): run '$0 up --demo' first"
  local url email pass fails=0 csrf
  url="$(saved RETAIL_PUBLIC_ORIGIN)"; email="$(saved RETAIL_ADMIN_EMAIL)"; pass="$(saved RETAIL_ADMIN_PASSWORD)"
  check() { local what="$1"; shift; if "$@" >/dev/null 2>&1; then say "ok:   $what"; else say "FAIL: $what"; fails=$((fails + 1)); fi; }
  body_has() { curl -fsS "$1" | grep -q "$2"; }
  login_ok() {
    local jar tmp; jar="$(mktemp)"; tmp="$(mktemp)"
    curl -fsS -c "$jar" -b "$jar" -H 'Content-Type: application/json' -H "Origin: $url" \
      -d "{\"email\":\"$email\",\"password\":\"$pass\"}" "$url/api/login" > "$tmp"
    grep -q '"csrf"' "$tmp"
    local code=$?; rm -f "$jar" "$tmp"; return $code
  }
  check "healthz reports the version" body_has "$url/healthz" '"version"'
  check "readyz reports the schema" body_has "$url/readyz" '"schema"'
  check "console HTML is served" body_has "$url/" 'Zyvor'
  check "admin can sign in with the saved password" login_ok
  if [ "$fails" -eq 0 ]; then say "all checks passed"; else say "$fails check(s) failed"; return 1; fi
}

case "$CMD" in
  up) do_up ;;
  test) do_test ;;
  engine) pick_engine; say "container engine ready: ${COMPOSE[*]}" ;;
  status) pick_engine; "$ENGINE" ps --filter "name=$PROJECT" --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' ;;
  logs) pick_engine; compose logs --tail 80 ;;
  down) pick_engine; [ -f "$ENVF" ] && compose down || true ;;
  uninstall)
    pick_engine
    if [ -f "$ENVF" ]; then compose down -v; fi
    say "Removed the containers and their data volumes. Settings and passwords remain in $DIR; delete that folder to remove them too."
    ;;
  *) sed -n '2,/^set -euo/p' "$0" | sed '$d' | sed 's/^# \{0,1\}//'; [ "$CMD" = help ] || exit 2 ;;
esac
